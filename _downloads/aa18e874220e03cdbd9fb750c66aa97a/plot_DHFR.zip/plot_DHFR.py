"""
DHFR proteases
====================

Load the dataset

"""

from cocoatree.datasets import load_DHFR

dataset = load_DHFR()
