"""
Rhomboid proteases
====================

Load the dataset

"""

from cocoatree.datasets import load_rhomboid_proteases

dataset = load_rhomboid_proteases()
