"""
S1A serine proteases
====================

Load the dataset

"""

from cocoatree.datasets import load_S1A_serine_proteases

dataset = load_S1A_serine_proteases()
